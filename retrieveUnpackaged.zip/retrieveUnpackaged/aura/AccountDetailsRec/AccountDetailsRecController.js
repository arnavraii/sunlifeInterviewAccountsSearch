({
    doInit: function(component, event, helper) {
        component.set('v.columns', [
            {label: 'Account Name', fieldName: 'linkName', type: 'url', 
            typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}},
            {label: 'Owner Name', fieldName: 'AccountOwner', type: 'text' ,editable: false},
            {label: 'Website', fieldName: 'Website', type: 'text' ,editable: true},
            {label: 'Phone', fieldName: 'Phone', type: 'phone' ,editable: true },
            {label: 'Annual Revenue', fieldName: 'AnnualRevenue', type: 'currency' ,editable: true},
        ]);
            helper.AllAccHelper(component, event);
       
    },
    Search: function(component, event, helper) {
        var searchField = component.find('searchField');
        var searchOwnerField = component.find('searchOwnerField');
        var isValueMissing = searchField.get('v.validity').valueMissing;
        var isOwnerValueMissing = searchField.get('v.validity').valueMissing;
        // if value is missing show error message and focus on field
        if(isValueMissing && isOwnerValueMissing) {
            searchField.showHelpMessageIfInvalid();
            searchField.focus();
            searchOwnerField.showHelpMessageIfInvalid();
            searchOwnerField.focus();
        }else{
          // else call helper function 
            helper.SearchHelper(component, event);
        }
    },
     handleSaveEdition: function (cmp, event, helper) {
        //to update the records
        var draftValues = event.getParam('draftValues');
        console.log(draftValues);
        var action = cmp.get("c.updateAccount");       
            action.setParams({"acc" : draftValues});
        action.setCallback(this, function(response) {
            var state = response.getState();
            $A.get('e.force:refreshView').fire();
            
        });
        $A.enqueueAction(action);
        
    },
})